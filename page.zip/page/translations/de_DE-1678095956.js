window.appTranslations = {
    "02": {
        "09": {
            "22 in Hamburg": null
        }
    },
    "14": {
        "09": {
            "22 in D\u00fcsseldorf": null
        }
    },
    "A3": {
        "5": null
    },
    "Sig": {
        "\/Sig": {
            "ra": null
        }
    },
    "c-badge-level-achievement": {
        "message": "Wir gratulieren Ihnen zu Ihrem abgeschlossenen Quiz. Mit den erreichten Punkten haben Sie ein neues Level erreicht. Sie k\u00f6nnen Ihre Punkte und das Zertifikat in Ihrem Profil einsehen.",
        "title": "Kurs abgeschlossen!"
    },
    "c-badge-level": {
        "badgePoints": "{count} Badge-Punkte | {count} Badge-Punkt | {count} Badge-Punkte",
        "ceBadgeLabel": "CE",
        "cePoints": "{count} CE-Punkte | {count} CE-Punkt | {count} CE-Punkte",
        "nextLevelPoints": "+{count} Punkte f\u00fcr das n\u00e4chste Level",
        "title": "Herzlichen Gl\u00fcckwunsch<br>Dies ist Ihre Gesamtpunktzahl:",
        "viewAllLinkLabel": "Alle anzeigen"
    },
    "c-badge-panel": {
        "downloadButtonLabel": "Zum Zertifikat"
    },
    "c-blog-list-item": {
        "readMoreLinkText": "Mehr erfahren"
    },
    "c-breadcrumb": {
        "back": "Zur\u00fcck",
        "linkTitle": "Gehe zu {name}"
    },
    "c-certificates-list": {
        "actions": "Aktionen",
        "badgeLevelReached": "Badge Level {name} erreicht",
        "cePoints": "CE Punkte",
        "courseDate": "Datum",
        "courseName": "Name",
        "courseNumber": "Kurs-Nr.",
        "download": "Herunterladen",
        "download-local-points-certificate": "Herunterladen",
        "downloadAll": "Alle herunterladen",
        "filterByYear": "Nach Jahr filtern",
        "title": "Zertifikate"
    },
    "c-chat-toggle": {
        "showChatWindow": "Chat anzeigen"
    },
    "c-cms-event-registration": {
        "buttonLabelClose": "Schliessen",
        "buttonLabelOpenRegistrationModal": "Jetzt anmelden",
        "buttonLabelSubmitForm": "Senden",
        "errorNotificationEmail": "Bitte geben Sie eine g\u00fcltige E-Mail-Adresse ein",
        "errorNotificationFirstName": "Bitte geben Sie Ihren Vornamen ein",
        "errorNotificationLastName": "Bitte geben Sie ihren Nachnamen ein",
        "errorNotificationMobile": "Bitte geben sie ihre Telefonnummer ein",
        "inputLabelEmail": "Email",
        "inputLabelEvent": "Event",
        "inputLabelFirstName": "Vorname",
        "inputLabelFormConsent": "Ich bin damit einverstanden, dass meine Daten bis zur Vergabe der Ausbildung gespeichert werden. Die Daten werden nach Besetzung der Lehrstelle gel\u00f6scht.",
        "inputLabelLastName": "Nachname",
        "inputLabelMobile": "Mobiltelefon",
        "inputLabelPrivacyPolicyConsent": "Ich habe {link} gelesen und bin damit einverstanden.",
        "inputLabelPrivacyPolicyConsentLink": "Zustimmung zur Datenschutzerkl\u00e4rung",
        "inputLabelSlot": "Datum",
        "optionLabelSlotFullyBooked": "{date} - ausgebucht",
        "textConfirmationMessage": "Ihre Anmeldung wurde gesendet.",
        "textNoEventsAvailable": "Es tut uns leid, leider sind keine Veranstaltungen verf\u00fcgbar.",
        "textNoSlotsAvailable": "Es tut uns leid, leider sind f\u00fcr diese Veranstaltung keine Termine verf\u00fcgbar.",
        "titleConfirmation": "Danke f\u00fcr deine Registrierung",
        "titleForm": "Veranstaltungsanmeldung"
    },
    "c-cms-tile": {
        "linkTitle": "Mehr erfahren"
    },
    "c-cms-video": {
        "playImageTitle": "Video abspielen"
    },
    "c-completed-courses": {
        "filterButtonText": "Filter ({amount})",
        "filterTitle": "Filter",
        "listTitle": "Keine Kurse gefunden | Teilgenommene Kurse (1) | Teilgenommene Kurse  ({count})",
        "resetAllFilterText": "Alle Filter zur\u00fccksetzen ({amount})",
        "submitFilterText": "Filter anwenden"
    },
    "c-confirmation-modal": {
        "cancel": "Abbrechen",
        "confirm": "Weiter"
    },
    "c-course-actions": {
        "basicCustomerInformationForPaidCourse": "Sie m\u00fcssen \u00fcber ein professionelles Konto verf\u00fcgen, um dies zu buchen. Wenn Sie auf die Schaltfl\u00e4che klicken, werden Sie zur Service-Seite weitergeleitet.",
        "booked": "Gebucht",
        "calendar": "Kalender",
        "coursePassed": "Kurs bestanden",
        "favourite": "Favourite",
        "getCEPoints": "CE Punkte holen",
        "goToWebinarMeeting": "Gehe zu Webinar",
        "onWaitingList": "Auf der Warteliste",
        "preliminaryBookingDisabled": "Dieser Kurs beginnt in weniger als 48h, weshalb keine Buchung mehr m\u00f6glich ist.",
        "quiz": "Das Quiz ausf\u00fcllen",
        "registerNow": "Jetzt registrieren",
        "registrationApproved": "Registrierung best\u00e4tigt",
        "registrationLink": "Jetzt registrieren",
        "registrationPending": "Registrierung in Bearbeitung",
        "userVerificationPending": "Verifizierung in Bearbeitung",
        "waitingList": "Warteliste"
    },
    "c-course-booking": {
        "close": "Schliessen",
        "confirm": "Best\u00e4tigen",
        "confirmationMessage": "Sie erhalten in K\u00fcrze eine Best\u00e4tigungsmail an die angegebene Adresse.<br>Bei Ivoclar ist das Lernen und Lehren fester Bestandteil unserer Unternehmenswerte.<br>Wir danken Ihnen f\u00fcr Ihre Zeit, die Sie mit uns verbringen.",
        "confirmationTitle": "Vielen Dank, dass Sie sich f\u00fcr dieses Weiterbildungsangebot der Ivoclar Academy angemeldet haben!",
        "coursePrice": "Kurskosten",
        "freeOfCharge": "Kostenlos",
        "legalNotice": "Mit Ihrer Best\u00e4tigung wird der genannte Betrag in Rechnung gestellt.",
        "message": "Bitte best\u00e4tigen Sie Ihre Buchung:",
        "title": "Vielen Dank \u2013 Sie k\u00f6nnen jetzt Ihre Buchung vornehmen",
        "waitingListConfirmationMessage": "Wir haben Sie der Warteliste hinzugef\u00fcgt.",
        "waitingListConfirmationTitle": "Best\u00e4tigung"
    },
    "c-course-lecturer": {
        "learnMore": "Mehr erfahren"
    },
    "c-course-organizer": {
        "organizerEmail": "E-Mail {email}",
        "organizerPhone": "Tel. {number}",
        "organizerTitle": "Fragen zum Kurs?"
    },
    "c-course-questionnaire": {
        "confirmationTitle": "Vielen Dank, dass Sie den Fragebogen f\u00fcr \"{course}\" ausgef\u00fcllt haben.",
        "content": "<h4>Bitte teilen Sie Ihre Eindr\u00fccke mit uns<\/h4>\n",
        "continueToAcademy": "Zur\u00fcck zur Akademie",
        "continueToCourse": "Zur\u00fcck zum Kurs",
        "mandatoryHint": "Pflichtfragen",
        "question1": "Wie zufrieden sind Sie mit den Kursinhalten?",
        "question2": "Wie zufrieden sind Sie mit der Qualit\u00e4t der eingesetzten Medien (Pr\u00e4sentation, Bilder, Visuals etc.)?",
        "question3": "Wie zufrieden sind Sie mit dem Referenten\/Lehrer?",
        "question4": "Wie zufrieden sind Sie insgesamt mit dem Studiengang?",
        "question5": "Was w\u00fcrden Sie \u00e4ndern, um zuk\u00fcnftige Erfahrungen zu verbessern?",
        "ratingHighLabel": "Sehr zufrieden",
        "ratingLowLabel": "Sehr unzufrieden",
        "submitLabel": "Senden",
        "title": "Vielen Dank f\u00fcr die Teilnahme am Kurs \"{course}\"."
    },
    "c-course-tile": {
        "availableSeats": "1 freier Platz | {count} freie Pl\u00e4tze",
        "calendarButton": "Kalender",
        "cancelButton": "Kurs ausblenden",
        "ceBadge": "CE",
        "cePoints": "CE-Punkte",
        "detailLink": "Mehr Details",
        "favouriteButton": "Favorit",
        "isFree": "kostenlos",
        "lecturer": "Von {name}",
        "localPoints": "Keine Punkte | +1 Punkt | +{count} Punkte",
        "localPointsShort": "LP",
        "onDemand": "On demand",
        "points": "Punkte",
        "waitingList": "Warteliste"
    },
    "c-dashboard": {
        "title": "Meine Academy",
        "titleCurrentCourses": "Meine aktuellen Kurse",
        "titleFavourites": "Meine neusten Favoriten",
        "viewAll": "Alle ansehen"
    },
    "c-data-table": {
        "noResults": "Keine Resultate",
        "sortAscending": "{sortName} aufsteigend",
        "sortBy": "Sortieren nach",
        "sortDescending": "{sortName} absteigend"
    },
    "c-date-picker": {
        "calendarTitle": "Zeitspanne",
        "close": "Schliessen",
        "inputEndName": "Bis:",
        "inputName": "Datum:",
        "inputStartName": "Von:",
        "nextMonth": "N\u00e4chster Monat",
        "previousMonth": "Vorheriger Monat"
    },
    "c-document-card": {
        "collapse": "Weniger anzeigen",
        "readMore": "Mehr lesen"
    },
    "c-download-list": {
        "archive": "Archiv",
        "image": "Bild",
        "pdf": "PDF Dokument",
        "video": "Video"
    },
    "c-electronic-instruction-banner": {
        "invalidReferenceNumberError": "Ihr Suchbegriff entspricht nicht dem Format einer Referenznummer\/UDI-DI. Bitte \u00fcberpr\u00fcfen Sie das Format oder kontaktieren Sie uns, wenn Sie Hilfe ben\u00f6tigen.",
        "legalNotice": "Bitte beachten Sie, dass diese Informationen nur f\u00fcr Dentalfachleute bestimmt sind. Durch die Nutzung dieser Webseite best\u00e4tigen Sie, dass Sie eine zahn\u00e4rztliche oder zahntechnische Fachperson sind.",
        "prefix": "Immer zur Hand \u2026",
        "referenceNumberExampleAlt": "Ein Beispiel, wie Sie die Referenznummer f\u00fcr Ihr Produkt finden.",
        "referenceNumberInfo": "Sie finden die Produktreferenznummer (REF-Nummer) wie abgebildet auf der Seite der Verpackung Ihres Produkts {tooltip}. Wenn Sie die REF-Nummer nicht finden k\u00f6nnen, verwenden Sie bitte die Website-Suche und geben Sie den Markennamen ein. ",
        "referenceNumberTooltipLabel": "hier",
        "searchFieldLabel": "Suche nach REF-Nummer...",
        "searchUrlLabel": "Suche",
        "title": "Willkommen bei der  elektronischen  Gebrauchsinformation (eIFU)"
    },
    "c-electronic-instruction-detail": {
        "currentVersion": "Aktuelle Version",
        "historyTitle": "Fr\u00fchere Versionen",
        "readInstructions": "Lesen Sie die Anweisungen zur Verwendung der eIFU",
        "titleValidAsOf": "G\u00fcltig ab {date}",
        "validAsOf": "G\u00fcltig ab {date}"
    },
    "c-electronic-instruction-download": {
        "buttonLabelBack": "Zur\u00fcck",
        "buttonLabelClose": "Schliessen",
        "buttonLabelDownload": "Herunterladen",
        "buttonLabelSubscribeAndDownload": "Abonnieren und herunterladen",
        "description": "Wenn Sie diese eIFU abonnieren, werden Sie per E-Mail an die von Ihnen angegebene E-Mail-Adresse \u00fcber alle \u00c4nderungen informiert, die diese eIFU betreffen.",
        "errorNotificationEmail": "Bitte geben Sie eine g\u00fcltige E-Mail-Adresse ein.",
        "formHeader": "Geben Sie bitte Ihre E-Mail-Adresse ein.",
        "inputLabelEmail": "E-Mail-Addresse",
        "inputLabelGeneralTermsOfUse": "Ich akzeptiere die {link}",
        "inputLabelGeneralTermsOfUseLink": "Allgemeine Gesch\u00e4ftsbedingungen.",
        "radioLabelDownload": "Nein, ich m\u00f6chte diese eIFU nicht abonnieren",
        "radioLabelSubscribe": "Ja, ich m\u00f6chte diese eIFU abonnieren",
        "textConfirmationMessage": "Wir haben Ihnen eine Best\u00e4tigungs-E-Mail gesendet. Bitte klicken Sie auf den Link in der E-Mail.",
        "title": "Abonnieren Sie alle neuen Versionen",
        "titleConfirmation": "Sie haben Updates abonniert"
    },
    "c-electronic-instruction-grid-tile": {
        "category": "Kategorie",
        "language": "Sprache",
        "linkTitle": "Mehr erfahren",
        "referenceNumber": "REF\/Artikelnummer",
        "statusTextImprovedVersionExists": "Diese eIFU-Version wurde ge\u00e4ndert. Bitte verwenden Sie die folgende eIFU-Version.",
        "statusTextInvalidDueSafety": "Diese \u00dcberarbeitung der Gebrauchsinformation wurde aus Sicherheitsgr\u00fcnden ge\u00e4ndert und wurde ung\u00fcltig. Bitte verwenden Sie die folgende eIFU-Version.",
        "udiDiNumber": "UDI-DI",
        "validAsOf": "G\u00fcltig ab {date}"
    },
    "c-electronic-instruction-list": {
        "multiLanguageVersion": "Mehrsprachig"
    },
    "c-electronic-instruction-problem": {
        "buttonLabelBack": "Zur\u00fcck",
        "buttonLabelClose": "Schliessen",
        "buttonLabelSubmit": "Senden",
        "errorNotificationEmail": "Entschuldigung, aber dies ist keine g\u00fcltige E-Mail",
        "errorNotificationFieldRequired": "Das Feld ist obligatorisch",
        "formTitle": "Melden Sie ein Problem mit der eIFU",
        "inputLabelComment": "Zus\u00e4tzlicher Kommentar",
        "inputLabelCompanyName": "Name der Firma",
        "inputLabelEmail": "E-Mail",
        "inputLabelFirstName": "Vorname",
        "inputLabelGeneralTermsOfUse": "Ja, ich habe {link} gelesen und verstanden",
        "inputLabelGeneralTermsOfUseLink": "die Allgemeinen Nutzungsbedingungen",
        "inputLabelLastName": "Nachname",
        "inputLabelPhone": "Telefon",
        "inputLabelSalutation": "Anrede",
        "messageApology": "Es tut uns leid, dass wir Ihre Erwartungen nicht erf\u00fcllt haben.",
        "messageInstructions": "Bitte schreiben Sie uns Ihr Anliegen \u00fcber das Kontaktformular. Wir werden uns so schnell wie m\u00f6glich mit Ihnen in Verbindung setzen.",
        "salutationOptionMr": "Herr",
        "salutationOptionMs": "Frau",
        "textConfirmationMessage": "Vielen Dank f\u00fcr die \u00dcbermittlung Ihrer Nachricht.",
        "titleConfirmation": "Ihre Meldung hat uns erreicht"
    },
    "c-electronic-instruction-request": {
        "buttonLabelBack": "Zur\u00fcck",
        "buttonLabelClose": "Schliessen",
        "buttonLabelSubmitForm": "Senden",
        "errorNotificationEmail": "Entschuldigung, aber dies ist keine g\u00fcltige E-Mail",
        "errorNotificationFieldRequired": "Das Feld ist obligatorisch",
        "formTitle": "Fordern Sie eine gedruckte Kopie der eIFU an",
        "genderOptionFemale": "Frau",
        "genderOptionMale": "Herr",
        "genderOptionNotDisclosed": "Eher nicht verraten",
        "inputLabelAddress": "Adresse",
        "inputLabelCity": "Stadt",
        "inputLabelComment": "Zus\u00e4tzlicher Kommentar",
        "inputLabelCompanyName": "Name der Firma",
        "inputLabelCountry": "Land",
        "inputLabelEmail": "E-Mail",
        "inputLabelFirstName": "Vorname",
        "inputLabelGender": "Anrede",
        "inputLabelGeneralTermsOfUse": "Ich akzeptiere die {link}",
        "inputLabelGeneralTermsOfUseLink": "Allgemeinen Nutzungsbedingungen",
        "inputLabelLastName": "Nachname",
        "inputLabelPhone": "Telefon",
        "inputLabelTitle": "Titel",
        "inputLabelZipCode": "Postleitzahl",
        "propertyToggleLabelCollapse": "Schliessen",
        "propertyToggleLabelExpand": "Erweitern",
        "referenceNumber": "Referenznummer",
        "textConfirmationMessage": "Vielen Dank f\u00fcr Ihre Anfrage nach einer Papierversion des IfU. Wir senden sie Ihnen innerhalb einer Woche per Post zu.",
        "titleConfirmation": "Ihre Anfrage ist bei uns angekommen",
        "udiDiNumber": "UDI-DI"
    },
    "c-electronic-instruction-search": {
        "brandSearchFieldLabel": "Suche nach Produktname...",
        "invalidReferenceNumberError": "Ihr Suchbegriff entspricht nicht dem Format einer Referenznummer\/UDI-DI. Bitte \u00fcberpr\u00fcfen Sie das Format oder kontaktieren Sie uns, wenn Sie Hilfe ben\u00f6tigen.",
        "refSearchFieldLabel": "Suche nach REF-Nummer...",
        "referenceNumberExampleAlt": "Ein Beispiel, wie Sie die Referenznummer f\u00fcr Ihr Produkt finden.",
        "referenceNumberInfo": "Durch die Suche nach der Referenznummer (REF-Nummer) erhalten Sie das genaue Ergebnis f\u00fcr Ihr Produkt. Sie finden die Produkt-REF-Nummer wie abgebildet auf der Seite der Verpackung Ihres Produkts {tooltip}. Wenn Sie die REF-Nummer nicht finden k\u00f6nnen, verwenden Sie bitte die Suche auf der rechten Seite und geben Sie den Produktnamen ein.",
        "referenceNumberTooltipLabel": "hier",
        "searchByBrandHint": "Wenn Sie nach dem Produktnamen suchen, finden Sie viele Ergebnisse, die mit dem Namen \u00fcbereinstimmen. Bitte stellen Sie sicher, dass Sie die richtige eIFU ausw\u00e4hlen. Bitte geben Sie den Namen Ihres gew\u00fcnschten Produkts ein.",
        "searchByBrandTitle": "Suche nach Name",
        "searchByRefTitle": "Suche nach REF-Nummer",
        "searchUrlLabel": "Suche",
        "separatorLabel": "oder"
    },
    "c-electronic-instruction-tile": {
        "availableLanguages": "Verf\u00fcgbare Sprachen",
        "category": "Kategorie",
        "countriesApplicable": "G\u00fcltig in den folgenden L\u00e4ndern",
        "download": "Herunterladen",
        "earlierVersions": "Fr\u00fchere Versionen",
        "fileId": "Datei-ID",
        "fileSize": "Dateigr\u00f6sse",
        "fileType": "Dateityp",
        "fileTypePDF": "PDF",
        "languages": "Sprachen",
        "moreToggleLabel": "mehr",
        "noMatch": "Keine \u00dcbereinstimmung",
        "propertyToggleLabelCollapse": "Schliessen",
        "propertyToggleLabelExpand": "Erweitern",
        "referenceNumber": "REF\/Artikelnummer",
        "reportProblem": "Melden Sie ein Problem mit der eIFU",
        "requestHardCopy": "Papierversion anfordern",
        "showLess": "Weniger anzeigen",
        "statusTextImprovedVersionExists": "Diese eIFU-Version wurde ge\u00e4ndert. Bitte verwenden Sie die folgende eIFU-Version.",
        "statusTextInvalidDueSafety": "Diese \u00dcberarbeitung der Gebrauchsinformation wurde aus Sicherheitsgr\u00fcnden ge\u00e4ndert und wurde ung\u00fcltig. Bitte verwenden Sie die folgende eIFU-Version.",
        "udiDiNumber": "UDI-DI",
        "validAsOf": "G\u00fcltig ab {date}",
        "view": "Ansehen"
    },
    "c-favourite-courses": {
        "listTitle": "Sie haben keine Kurse gespeichert. | Ihre gespeicherten Kurse (1) | Ihre gespeicherten Kurse ({count})"
    },
    "c-filter": {
        "selectPlaceholder": "Bitte w\u00e4hlen",
        "unsupportedTypeError": null
    },
    "c-flyout": {
        "closeButtonTitle": "Schliessen"
    },
    "c-footer": {
        "certificatesLabel": "Diese Website ist sicher",
        "socialLabel": "Folgen Sie uns auf unseren sozialen Medien",
        "toTopLabel": "Nach oben"
    },
    "c-gatekeeper-modal": {
        "cancelLabel": null,
        "confirmLabel": null,
        "declineLabel": null,
        "message": null
    },
    "c-header": {
        "cartAlt": "Warenkorb",
        "cartTitle": "Warenkorb",
        "logoAlt": "Logo",
        "menuAlt": "Navigation",
        "searchAlt": "Suche",
        "searchLabel": "Suche nach\u2026",
        "userGreeting": "Willkommen, {name}."
    },
    "c-hero-message": {
        "pimcorePictureOverlayVariantLabel": "Verlaufsmaske (Bild)",
        "pimcorePictureOverlayVariantLabelDark": "Dunkel",
        "pimcorePictureOverlayVariantLabelLight": "Hell",
        "pimcorePictureOverlayVariantLabelRegular": "Normal"
    },
    "c-ids-menu-tile": {
        "showMore": "Mehr erfahren",
        "tabTitleGeneral": null,
        "tabTitleLink": null
    },
    "c-ids-product-card": {
        "detailLink": "Mehr erfahren"
    },
    "c-ids-screensaver": {
        "tabToStartLink": "Zum Starten den Bildschirm ber\u00fchren \/ Please touch screen to start"
    },
    "c-ids-workflow-detail": {
        "stepLabel": "{index}. {text}"
    },
    "c-ids-workflow-step": {
        "moreOnIvoclar": "Mehr auf Ivoclar"
    },
    "c-ids-workflow-steps": {
        "stepLabel": "{index}. {text}"
    },
    "c-ids-workflows-overview": {
        "showMore": "Mehr erfahren"
    },
    "c-language-menu": {
        "changeRegion": "Region wechseln",
        "title": "Sprache w\u00e4hlen",
        "toggleFallback": "Sprache"
    },
    "c-main-navigation-mobile": {
        "backButtonTitle": "Zur\u00fcck zu {label}",
        "backToOverview": "Zur\u00fcck zur \u00dcbersicht"
    },
    "c-main-navigation": {
        "closeButtonTitle": "Schliessen"
    },
    "c-market-selector": {
        "languageLabel": "Sprache",
        "marketLabel": "Land",
        "submitLabel": "Weiter",
        "text": "Besuchen Sie unsere Website in Ihrem Land! W\u00e4hlen Sie Ihr Land aus der folgenden Liste:",
        "title": "Land w\u00e4hlen"
    },
    "c-modal": {
        "closeTitle": "Fenster schliessen"
    },
    "c-newsletter": {
        "emailLabel": "Ihre E-Mail Adresse",
        "tocLabel": "Ich habe die {link} gelesen.",
        "tocLinkLabel": "AGB"
    },
    "c-notification": {
        "close": "Schliessen",
        "confirm": "OK",
        "decline": "Abbrechen",
        "errorTitle": "Error",
        "infoTitle": "Info",
        "successTitle": "Best\u00e4tigung",
        "warningTitle": "Warnung"
    },
    "c-pagination": {
        "backButtonTitle": "Vorherige Seite",
        "forwardButtonTitle": "N\u00e4chste Seite",
        "itemsPerPageLabel": "Anzahl pro Seite",
        "selectPageLabel": "Seite w\u00e4hlen"
    },
    "c-personalized-message": {
        "message": "{salutation} {greeting}!<br \/> \nIn Ihrem pers\u00f6nlichen Ivoclar-Kundenbereich finden Sie alle relevanten Informationen, L\u00f6sungen und Services.",
        "salutationFemale": "Sehr geehrte Frau",
        "salutationMale": "Sehr geehrter Herr.",
        "salutationOther": "Herzlich Willkommen"
    },
    "c-product-tile": {
        "detailLink": "Mehr Details",
        "shopLink": "Zum Online-Shop"
    },
    "c-profile-navigation-trigger": {
        "label": "Mein Konto"
    },
    "c-profile-navigation": {
        "closeButton": "Schliessen",
        "titleAcademy": "Academy",
        "titlePortalFeatures": "Portalfunktionen",
        "titleProfile": "Mein Profil",
        "titleShop": "Shop"
    },
    "c-quiz": {
        "buttonRetry": "Erneut versuchen",
        "courseFailedLink": "Lektion erneut anschauen",
        "coursePassedLink1": "Zur\u00fcck zum Kurs",
        "coursePassedLink2": "N\u00e4chster Kurs",
        "failedText": "Sie haben {number}% der Fragen richtig beantwortet. Leider reicht das nicht aus, um ein Zertifikat zu erhalten. Versuchen Sie es noch einmal.",
        "failedTitle": "Nah dran!",
        "passedText": "Sie haben gen\u00fcgend Fragen richtig beantwortet und den Kurs daher bestanden - sehr gut! Das Zertifikat erhalten Sie per Email. Beginnen Sie gleich den n\u00e4chsten Kurs.",
        "passedTitle": "Gratulation!",
        "submitButton": "Absenden und Punkte erhalten",
        "title": "Quiz"
    },
    "c-revealable-text": {
        "buttonLabel": "Mehr"
    },
    "c-scroll-top": {
        "buttonTitle": null
    },
    "c-search-banner": {
        "closeButtonTitle": "Schliessen",
        "hasResultsText": "Nicht was Sie suchen? Versuchen Sie es bitte im {link}.",
        "hasResultsTextLink": "Shop",
        "noResultsLinkTextShopTab": "kontaktieren Sie uns",
        "noResultsLinkTextWebsiteTab": "kontaktieren Sie uns",
        "noResultsText": "Keine Resultate gefunden, versuchen Sie die Suche im Shop",
        "noResultsTextLink": "Shop",
        "noResultsTextShopDisabled": "Entschuldigung, wir konnten keine Resultate finden.",
        "noResultsTextShopTab": "Entschuldigung, wir konnten keine Resultate zu Ihrem Suchbegriff finden. Wenn Sie Informationen vermissen, bitte {link}.",
        "noResultsTextWebsiteTab": "Entschuldigung, wir konnten keine Resultate zu Ihrem Suchbegriff finden. Wenn Sie Informationen vermissen, bitte {link}.",
        "relatedResultsTitle": "Am meisten gesucht",
        "searchFieldLabel": "Ich suche nach \u2026",
        "searchResultsTitle": "Suchresultate",
        "submitSearchButtonText": "Suchen",
        "tabShop": "Shop",
        "tabWebsite": "Webseite",
        "titleRow1": "Hallo {name},",
        "titleRow2": "Wie k\u00f6nnen wir dir helfen?"
    },
    "c-search-bar": {
        "closeLabel": "Schliessen",
        "hasResultsText": "Nicht was Sie suchen? Versuchen Sie es bitte im {link}.",
        "hasResultsTextLink": "Shop",
        "noResultsLinkText": "Zum Kontaktformular",
        "noResultsLinkTextShopTab": "kontaktieren Sie uns",
        "noResultsLinkTextWebsiteTab": "kontaktieren Sie uns",
        "noResultsText": "Keine Resultate gefunden, versuchen Sie die Suche im Shop",
        "noResultsTextLink": "Shop",
        "noResultsTextShopDisabled": "Entschuldigung, wir konnten keine Resultate finden.",
        "noResultsTextShopTab": "Entschuldigung, wir konnten keine Resultate zu Ihrem Suchbegriff finden. Wenn Sie Informationen vermissen, bitte {link}.",
        "noResultsTextWebsiteTab": "Entschuldigung, wir konnten keine Resultate zu Ihrem Suchbegriff finden. Wenn Sie Informationen vermissen, bitte {link}.",
        "quickLinksTitle": "Quick Links",
        "searchLabel": "Suche nach \u2026",
        "searchSuggestionsTitle": "Resultate",
        "showAllText": "Alle anzeigen",
        "tabShop": "Shop",
        "tabWebsite": "Webseite"
    },
    "c-select": {
        "optionsEmpty": "Keine Ergebnisse.",
        "save": "Speichern",
        "search": "suchen",
        "searchTitle": "Suche"
    },
    "c-slider-1": {
        "nextLabel": "Weiter",
        "previousLabel": "Zur\u00fcck"
    },
    "c-slider-2": {
        "nextLabel": "Weiter",
        "previousLabel": "Zur\u00fcck"
    },
    "c-social-sharing": {
        "linkTitle": "Auf {platform} teilen"
    },
    "c-status-message": {
        "error_code_0": "Herzlich Willkommen!\nIhre E-Mail-Adresse wurde best\u00e4tigt.\nIhr pers\u00f6nlicher Ivoclar-Kundenbereich bietet Ihnen alle relevanten Informationen, L\u00f6sungen und Dienstleistungen.",
        "error_code_403002": "Entschuldigung, der Link ist abgelaufen.",
        "error_code_other": "Leider gab es ein Problem."
    },
    "c-teaser-1": {
        "showAdditionalInfoBoxLabel": "Infobox mit blauem Hintergrund anzeigen",
        "showAdditionalInfoBoxText": "Dieses Produkt ist nicht f\u00fcr die breite \u00d6ffentlichkeit erh\u00e4ltlich. Befolgen Sie immer die Gebrauchsanweisung."
    },
    "c-user-courses": {
        "cancelBookingConfirmationLabel": "Abbrechen",
        "cancelBookingText": "Wenn Sie fortfahren, wird dieser Kurs aus Ihrer Liste ausgeblendet. Dies kann nicht r\u00fcckg\u00e4ngig gemacht werden.",
        "cancelBookingTitle": "Kurs ausblenden",
        "confirmBookingConfirmationLabel": "Weiter",
        "filterButtonText": "Filter ({amount})",
        "filterTitle": "Filter",
        "listTitle": "Ihre nicht abgeschlossenen Kurse ({count})",
        "listTitleCompletedCourses": "Ihre abgeschlossenen Kurse ({count})",
        "listTitleUncompletedCourses": "Ihre nicht abgeschlossenen Kurse ({count})",
        "resetAllFilterText": "Alle Filter zur\u00fccksetzen ({amount})",
        "submitFilterText": "Filter anwenden"
    },
    "c-user-navigation": {
        "loginButtonText": "Login",
        "logoutButtonText": "Logout"
    },
    "c-welcome-modal": {
        "actionCloseLabel": "Danke, diese Info schlie\u00dfen",
        "title": "Hallo {name}\nWir freuen uns, dass Sie hier sind!"
    },
    "e-course-availability": {
        "availableSeats": "1 freier Platz | {count} freie Pl\u00e4tze",
        "waitingList": "Warteliste"
    },
    "e-date": {
        "defaultLabel": "Datum:"
    },
    "e-progress": {
        "loading": "Lade \u2026"
    },
    "e-search": {
        "reset": "Zur\u00fccksetzen",
        "submit": "Suchen"
    },
    "e-select": {
        "chooseOption": "Bitte w\u00e4hlen"
    },
    "e-table": {
        "noResults": "Keine Ergebnisse f\u00fcr die aktuelle Auswahl.",
        "sort": "Nach {name} sortieren"
    },
    "form": {
        "label,my": {
            "labelFirst Name": null
        },
        "labelFirst Name": null
    },
    "form_builder": {
        "dynamic_multi_file": {
            "active_drop_area": null,
            "additions_removals": "zus\u00e4tzliche entfernen",
            "cancel": "Abbrechen",
            "canceled": "abgebrochen",
            "close": "Schlie\u00dfen",
            "delete": "L\u00f6schen",
            "delete_failed": "L\u00f6schen fehlgeschlagen",
            "deleting": "L\u00f6sche...",
            "drop_files_here": "Dateien hierherziehen",
            "edit_filename": "Dateiname bearbeiten",
            "file_invalid_extension": "Die Datei besitzt eine ung\u00fcltige Dateiendung. G\u00fcltige Dateiendung(en): {extensions}.",
            "file_is_empty": "Die Datei ist leer, bitte w\u00e4hlen Sie die Dateien ohne diese Datei erneut.",
            "file_is_too_large": "Die Datei ist zu gro\u00df, maximale Dateigr\u00f6\u00dfe ist {sizeLimit}MB.",
            "file_is_too_small": "Die Datei ist zu klein, minimale Dateigr\u00f6\u00dfe ist {minSizeLimit}",
            "files_uploaded": "Dateien werden hochgeladen - wenn Sie diese Seite verlassen, wird der Upload abgebrochen.",
            "global": {
                "cannot_destroy_active_instance": "Ein Uploader ist derzeit in dieser Sektion aktiv oder es wurden bereits Daten verarbeitet. Falls es bereits hochgeladene Dateien gibt, entfernen Sie diese bitte zuerst."
            },
            "image_not_tall_enough": "Bild ist zu klein.",
            "image_not_wide_enough": "Bild ist zu schmal.",
            "image_too_tall": "Bild ist zu gro\u00df.",
            "image_too_wide": "Bild ist zu breit.",
            "no": "Nein",
            "no_files_to_upload": "Keine Dateien zum hochladen.",
            "ok": null,
            "paused": "Pausiert",
            "percent_of_size": "{percent}% von {total_size}",
            "processing": "Verarbeite...",
            "processing_dropped_files": "Vearbeite Daten...",
            "remove": "entfernen",
            "retry": "Erneut versuchen",
            "retry_failed_limit": "Wiederholung fehlgeschlagen - Sie haben das Dateilimit erreicht.",
            "sure_to_cancel": "M\u00f6chten Sie den Vorgang wirklich abbrechen?",
            "sure_to_delete": "M\u00f6chten Sie die Datei {filename} wirklich l\u00f6schen?",
            "too_many_items": "Zuviele Dateien gew\u00e4hlt.",
            "unrecoverable_error": "Unbehebbarer Fehler aufgetreten.",
            "upload_a_file": "Datei hochladen",
            "upload_failed": "Upload fehlgeschlagen.",
            "yes": "Ja"
        },
        "fatal_captcha_error": "Beim Laden von Formularrelevanten Dateien sind Fehler aufgetreten. Bitte kontaktieren Sie den Administrator der Seite.",
        "form": {
            "container": {
                "repeater": {
                    "max": "%label%: Maximal %items% Eintr\u00e4ge erlaubt.",
                    "min": "%label%: Es werden mindestens %items% Eintr\u00e4ge ben\u00f6tigt."
                }
            }
        },
        "reCaptchaDisclaimer": "Diese Website ist durch reCAPTCHA gesch\u00fctzt und es gelten die <a href=\"https:\/\/policies.google.com\/privacy\" target=\"_blank\">Google-Datenschutzbestimmungen<\/a> und <a href=\"https:\/\/policies.google.com\/terms\" target=\"_blank\">Nutzungsbedingungen<\/a>."
    },
    "form_builder_form_template": {
        "form_ivoclar_layout": "Ivoclar"
    },
    "form_builder_form_template_negative": {
        "form_ivoclar_layout": "Ivoclar negative"
    },
    "globalMessages": {
        "certificateDownloadError": "Zertifikat Download nicht m\u00f6glich.",
        "loginUnavailable": "Beim Initialisieren der Login- und Registrierungsfunktionalit\u00e4t ist ein Fehler aufgetreten. Bitte kontaktieren Sie den Administrator.",
        "unknownApiError": "Es ist ein unbekannter Fehler aufgetreten.",
        "userAccountNotPrepared": "Das verwendete Konto ist noch nicht aktiv.",
        "userAccountNotPreparedTitle": "Konto in Vorbereitung",
        "userAssignedToDifferentSite": "Das verwendete Konto ist einem anderen Markt zugewiesen.",
        "userAssignedToDifferentSiteTitle": "Falscher Markt",
        "userLocked": "Das verwendete Konto ist blockiert.",
        "userLockedTitle": "Konto blockiert"
    },
    "ics": {
        "alert": {
            "30-minutes": null
        }
    },
    "l-badge-certificate": {
        "company": "Ivoclar Academy",
        "statement": "Die Ivoclar Academy bietet vollen Zugang<br \/> zu Bildungsressourcen auf h\u00f6chstem Niveau von f\u00fchrenden Experten<br \/> aus der ganzen Welt.",
        "subtitle": "Best\u00e4tigt den Rang f\u00fcr",
        "title": "Zertifikat"
    },
    "l-blog-list": {
        "filterButtonText": "Filter",
        "filterTitle": "Filter",
        "itemsPerPageLabel": "Anzahl pro Seite",
        "noResultsText": "Keine Eintr\u00e4ge gefunden",
        "resetAllFilterText": "Alle Filter zur\u00fccksetzen ({amount})",
        "sortingLabel": "Sortierung",
        "sortingLabelDateAsc": "Datum aufsteigend",
        "sortingLabelDateDesc": "Datum absteigend",
        "sortingViewsAsc": "Ansichten aufsteigend",
        "sortingViewsDesc": "Ansichten absteigend",
        "submitFilterText": "Filter anwenden",
        "topic": "Thema"
    },
    "l-course-certificate": {
        "ceHours": "CE\/Stunden",
        "courseCode": "Code",
        "courseDate": "Kursdatum",
        "courseRegistrationId": "Course registration ID",
        "educationalMethod": "Fortbildungsmethode",
        "issueId": "Issue ID",
        "localPoints": "Local points",
        "location": "Ort",
        "personalLicenseNumber": "Lizenznummer",
        "providerAddress": "Anbieteradresse",
        "providerAgdId": "AGD-ID-Nummer",
        "providerName": "Anbieter",
        "speaker": "Referent(en)",
        "title": "Zertifikat",
        "titleSuffix": null
    },
    "l-course-detail": {
        "ceLabel": "CE",
        "cePoints": "Keine CE-Punkte | +{count} CE-Punkt | +{count} CE-Punkte",
        "contactTitle": "Kontakt",
        "courseNumber": "Kurs-Nr. {number}",
        "downloadsTitle": "Dokumente",
        "isFree": "kostenlos",
        "localPoints": "Keine Punkte | +1 Punkt | +{count} Punkte",
        "localPointsShort": "LP",
        "localTime": "Lokalzeit",
        "locationTitle": "Ort",
        "mapLinkText": "Auf Karte zeigen",
        "notificationMessageBookingApproved": "Kurs verf\u00fcgbar sobald er startet",
        "notificationMessageBookingDeadlineOver": "Der Kurs kann nicht mehr gebucht werden",
        "notificationMessageBookingPassed": "Kurs bestanden",
        "notificationMessageBookingRegistrationPending": "Registrierung in Bearbeitung",
        "notificationMessageBookingRejected": "Registrierung wurde abgelehnt",
        "notificationMessageBookingWaitingList": "Registriert auf Warteliste",
        "notificationMessageUserVerificationPending": "Benutzer Verifizierung in Bearbeitung",
        "organizerEmail": "E-Mail {email}",
        "organizerPhone": "Tel. {number}",
        "organizerTitle": "Fragen zum Kurs?",
        "playVideoLabel": "Video abspielen",
        "points": "Keine Punkte | +1 Punkt | +{count} Punkte",
        "recommendationsTitle": "Empfohlene Kurse",
        "utc": "UTC"
    },
    "l-course-list": {
        "filterButtonText": "Filter ({amount})",
        "filterTitle": "Filter",
        "itemsPerPageLabel": "Anzahl pro Seite",
        "moreFilters": "Erweiterte Filter",
        "noResultsText": "Keine Eintr\u00e4ge gefunden",
        "resetAllFilterText": "Alle Filter zur\u00fccksetzen ({amount})",
        "sortingLabel": "Sortierung",
        "sortingLabelDateAsc": "Datum aufsteigend",
        "sortingLabelDateDesc": "Datum absteigend",
        "submitFilterText": "Filter anwenden",
        "title": "Weiterbildungsangebote ({amount})"
    },
    "l-course-local-certificate": {
        "courseCode": null,
        "courseDate": "Kursdatum",
        "educationalMethod": "P\u00e4dagogische Methode",
        "localPoints": "Lokale Punkte",
        "personalLicenseNumber": "Lizenznummer",
        "providerAddress": "Adresse des Anbieters",
        "providerAgdId": "Anbieter ID#",
        "providerName": "Name des Anbieters",
        "speaker": "Sprecher",
        "title": "Zertifikat"
    },
    "l-electronic-instruction-list": {
        "languageVersion": "{language} Version | Mehrsprachige Version",
        "legalNotice": "Bitte beachten Sie, dass diese Informationen nur f\u00fcr Dentalfachleute bestimmt sind. Durch die Nutzung dieser Webseite best\u00e4tigen Sie, dass Sie eine zahn\u00e4rztliche oder zahntechnische Fachperson sind.",
        "noBrandResults": "Leider konnten wir kein Dokument finden, das Ihrer Suche entspricht. Bitte kontaktieren Sie uns und wir werden Ihnen die gew\u00fcnschten Informationen so schnell wie m\u00f6glich zur Verf\u00fcgung stellen.",
        "noBrandResultsNotification": "Leider konnten wir kein Dokument finden, das Ihrer Suche entspricht. Bitte kontaktieren Sie uns und wir werden Ihnen die gew\u00fcnschten Informationen so schnell wie m\u00f6glich zur Verf\u00fcgung stellen.",
        "noResults": "Leider konnten wir kein Asset finden, das mit dieser Referenznummer \u00fcbereinstimmt. Bitte kontaktieren Sie uns und wir stellen Ihnen die gew\u00fcnschten Informationen so schnell wie m\u00f6glich zur Verf\u00fcgung.",
        "noResultsNotification": "Leider konnten wir kein Asset finden, das mit dieser Referenznummer \u00fcbereinstimmt. Bitte kontaktieren Sie uns und wir stellen Ihnen die gew\u00fcnschten Informationen so schnell wie m\u00f6glich zur Verf\u00fcgung.",
        "onlyHistoricalResults": "Diese Referenznummer konnte nur in historischen Versionen gefunden werden.",
        "reportProblemLabel": "Melden Sie ein eIFU-Problem",
        "searchUrlLabel": "Suche",
        "teaserText": "Um die passende Gebrauchsanweisung f\u00fcr Ivoclar-Produkte zu finden, geben Sie bitte entweder die Produktreferenznummer (REF-Nummer) oder alternativ den Produktnamen ein.",
        "title": "Willkommen bei der elektronischen Gebrauchsinformation (eIFU)"
    },
    "l-ids-business-card-scanner": {
        "cameraPermissionRevoked": "Kameraerlaubnis ablehnen",
        "cameraTitle": "Visitenkarten-Scanner",
        "description": "Fotografieren Sie die Visitenkarte mit dem untenstehen Button",
        "formTitle": "Visitenkarten-Scanner",
        "takePhoto": "Fotografieren",
        "takePhotoAgain": "Nochmals fotografieren",
        "takenPhotoDescription": "Wenn Sie noch einmal fotografieren m\u00f6chten"
    },
    "l-ids-homepage": {
        "headlineMenuPreview": null,
        "menuDescription": null
    },
    "l-product-list": {
        "filterButtonText": "Filter {amount}",
        "filterTitle": "Filter",
        "itemsPerPageLabel": "Anzahl pro Seite",
        "noResultsText": "Keine Eintr\u00e4ge gefunden",
        "resetAllFilterText": "Alle Filter zur\u00fccksetzen {amount}",
        "submitFilterText": "Filter anwenden",
        "title": "Produkte {amount}"
    },
    "l-search-results": {
        "filterButtonText": "Filter",
        "filterTitle": "Filter",
        "indexAll": "Alle Resultate ({count})",
        "indexArticle": "Artikel ({count})",
        "indexBlog": "Blog ({count})",
        "indexCourse": "Academy ({count})",
        "indexDocuments": "Dokumente ({count})",
        "indexEifu": "Gebrauchsanweisungen ({count})",
        "indexLabel": "Resultate",
        "indexLabelAll": "Alle Resultate",
        "indexLabelArticles": "Artikel",
        "indexLabelBlog": "Blog",
        "indexLabelCourse": "Academy",
        "indexLabelDocuments": "Dokumente",
        "indexLabelEifuasset": "eIFU",
        "indexLabelEifuassets": "eIFU",
        "indexLabelProduct_objects": null,
        "indexLabelProducts": "Produkte",
        "indexLabelPublications": "Publikationen",
        "indexLabelSolutions": "Solutions",
        "indexLabelUndefined": "Unbekannt",
        "indexProduct": "Produkte ({count})",
        "indexPublications": "Publikationen ({count})",
        "indexShop": "Shop",
        "indexSolution": null,
        "indexUndefined": "Unbekannt ({count})",
        "itemPerPageSelect": "Resultate",
        "itemsPerPageLabel": "Anzahl pro Seite",
        "resetAllFilterText": "Alle Filter zur\u00fccksetzen ({amount})",
        "searchClearLabel": "L\u00f6schen",
        "searchTerm": "Suchbegriff",
        "submitFilterText": "Filter anwenden",
        "title": "Keine Resultate gefunden f\u00fcr \"{term}\" | Wir haben 1 Resultat gefunden f\u00fcr \"{term}\", f\u00fcr mehr Produkte, klicken Sie auf den Shop-Tab | Wir haben {count} Resultate gefunden f\u00fcr \"{term}\", f\u00fcr mehr Produkte, klicken Sie auf den Shop-Tab",
        "titleLoadingResults": "Resultate werden geladen",
        "titleNoQuery": "Kein Suchbegriff eingegeben"
    },
    "l-services": {
        "accountDeviceRegistrationCancelLabel": "Abbrechen",
        "accountDeviceRegistrationConfirmLabel": "Kostenloses Registrieren",
        "accountDeviceRegistrationText": "Mit Ihrem derzeitigen Kontoprofil k\u00f6nnen Sie nicht die gesamte Palette der Dienstleistungen nutzen. Bitte aktualisieren Sie Ihr Konto.",
        "accountDeviceRegistrationTitle": "Aktualisieren Sie Ihr Konto, um Ihr Ger\u00e4t zu registrieren",
        "accountUpdateAndDeviceRegistrationCancelLabel": "Abbrechen",
        "accountUpdateAndDeviceRegistrationConfirmLabel": "Kostenloses Upgrade",
        "accountUpdateAndDeviceRegistrationText": "Mit Ihrem derzeitigen Kontoprofil k\u00f6nnen Sie nicht die gesamte Palette der Dienstleistungen nutzen. Bitte aktualisieren Sie Ihr Konto.",
        "accountUpdateAndDeviceRegistrationTitle": "Aktualisieren Sie Ihr Konto, um Ihr Ger\u00e4t zu registrieren",
        "accountUpdateConfirmLabel": "Kostenloses Upgrade",
        "accountUpdateText": "Mit Ihrem aktuellen Kontoprofil k\u00f6nnen Sie nicht alle Dienste in Anspruch nehmen. Bitte aktualisieren Sie Ihr Konto.",
        "accountUpdateTitle": "Aktualisieren Sie Ihr Konto",
        "cancelaccountUpdateLabel": "Abbrechen",
        "loginLabel": "Jetzt einloggen",
        "signupPendingLabel": "Schnelles Update",
        "signupPendingMessage": "Bitte haben Sie noch etwas Geduld, bis wir Sie per E-Mail benachrichtigen, dass Ihnen der volle Leistungsumfang zur Verf\u00fcgung steht.",
        "signupSuccessLabel": "Schnelles Update",
        "signupSuccessMessage": "Alle Funktionen Ihres Kundenportals sind aktiviert. Geben Sie jetzt Ihre erste Bestellung auf oder buchen Sie Ihren Kurs.",
        "upgradeButtonLabel": "Kostenloses Upgrade!",
        "upgradeNotificationLabel": "Schnelles Update",
        "upgradeNotificationMessageAllServices": "Alle Funktionen Ihres Kundenportals sind freigeschaltet. Geben Sie jetzt Ihre erste Bestellung auf oder buchen Sie Ihren Kurs.",
        "upgradeNotificationMessageBasic": "Kostenloses Upgrade f\u00fcr vollen Zugriff auf alle Funktionalit\u00e4ten",
        "upgradeNotificationMessageSignup": "Melden Sie sich jetzt an, um die Vorteile zu nutzen!",
        "upgradeNotificationMessageUpgradePending": "Wir bitten Sie um etwas Geduld, bis wir Sie per E-Mail benachrichtigen, dass Ihnen der volle Leistungsumfang zur Verf\u00fcgung steht."
    },
    "simpleevent": {
        "ics": {
            "alert": {
                "1-day": null,
                "30-minutes": null
            }
        }
    }
};