window.appTranslations = {
    "02": {
        "09": {
            "22 in Hamburg": null
        }
    },
    "14": {
        "09": {
            "22 in D\u00fcsseldorf": null
        }
    },
    "A3": {
        "5": null
    },
    "Sig": {
        "\/Sig": {
            "ra": null
        }
    },
    "c-badge-level-achievement": {
        "message": "We congratulate you on your completed quiz. With the points you have achieved, you reached a new level. You can see your points and the certificate in your profile.",
        "title": "Course completed!"
    },
    "c-badge-level": {
        "badgePoints": "{count} Badge-Points | {count} Badge-Point | {count} Badge-Points",
        "ceBadgeLabel": "CE",
        "cePoints": "{count} CE-Points | {count} CE-Point | {count} CE-Points",
        "nextLevelPoints": "Earn +{count} points to get next level.",
        "title": "Congratulations<br>This is your total score:",
        "viewAllLinkLabel": "view all"
    },
    "c-badge-panel": {
        "downloadButtonLabel": "Get certificate"
    },
    "c-blog-list-item": {
        "readMoreLinkText": "Read more"
    },
    "c-breadcrumb": {
        "back": "Back",
        "linkTitle": "Go to {name}"
    },
    "c-certificates-list": {
        "actions": "Actions",
        "badgeLevelReached": "Badge level {name} reached",
        "cePoints": "CE points",
        "courseDate": "Date",
        "courseName": "Name",
        "courseNumber": "Course-Nr.",
        "download": "Download",
        "download-local-points-certificate": "Download",
        "downloadAll": "Download all",
        "filterByYear": "Filter by year",
        "title": "Certificates"
    },
    "c-chat-toggle": {
        "showChatWindow": "Show chat"
    },
    "c-cms-event-registration": {
        "buttonLabelClose": "Close",
        "buttonLabelOpenRegistrationModal": "Register now",
        "buttonLabelSubmitForm": "Submit",
        "errorNotificationEmail": "Please enter a valid E-Mail address",
        "errorNotificationFirstName": "Please enter your first name",
        "errorNotificationLastName": "Please enter your last name",
        "errorNotificationMobile": "Please enter your phone number",
        "inputLabelEmail": "E-Mail",
        "inputLabelEvent": "Event",
        "inputLabelFirstName": "First name",
        "inputLabelFormConsent": "I agree that my data will be saved until the apprenticeship is assigned. The data will be deleted after the apprenticeship has been filled.",
        "inputLabelLastName": "Last name",
        "inputLabelMobile": "Mobile",
        "inputLabelPrivacyPolicyConsent": "I read and agree to the {link}.",
        "inputLabelPrivacyPolicyConsentLink": "Privacy Policy Consent",
        "inputLabelSlot": "Date",
        "optionLabelSlotFullyBooked": "{date} - fully booked",
        "textConfirmationMessage": "Your registration was sent.",
        "textNoEventsAvailable": "We are sorry, unfortunately there are no events available.",
        "textNoSlotsAvailable": "We are sorry, unfortunately there are no dates available for this event.",
        "titleConfirmation": "Thank you for your registration",
        "titleForm": "Event registration"
    },
    "c-cms-tile": {
        "linkTitle": "More details"
    },
    "c-cms-video": {
        "playImageTitle": "Play video"
    },
    "c-completed-courses": {
        "filterButtonText": "Filter ({amount})",
        "filterTitle": "Filter",
        "listTitle": "Found no courses. | Completed courses (1) | Completed courses ({count})",
        "resetAllFilterText": "Reset all filters ({amount})",
        "submitFilterText": "Apply filters"
    },
    "c-confirmation-modal": {
        "cancel": "Cancel",
        "confirm": "Continue"
    },
    "c-course-actions": {
        "basicCustomerInformationForPaidCourse": "You need to be on a professional account to book this. We will redirect you to the service page by clicking the button.",
        "booked": "Booked",
        "calendar": "Calendar",
        "coursePassed": "Course passed",
        "favourite": "Favorit",
        "getCEPoints": "Get CE-Points",
        "goToWebinarMeeting": "Go to webinar meeting",
        "onWaitingList": "On waiting list",
        "preliminaryBookingDisabled": "Unfortunately, we can accept bookings only until 48h before the course starts",
        "quiz": "Do the quiz",
        "registerNow": "Register now",
        "registrationApproved": "Registration confirmed",
        "registrationLink": "Register now",
        "registrationPending": "Registration in progress",
        "userVerificationPending": "Verification in progress",
        "waitingList": "Waiting list"
    },
    "c-course-booking": {
        "close": "Close",
        "confirm": "Confirm",
        "confirmationMessage": "A confirmation email will be sent to the address provided.<br>At Ivoclar, learning and teaching is at the core of our company values.<br>We thank you in advance for spending your time with us.",
        "confirmationTitle": "Thank you for registering for the Ivoclar Academy learning opportunity!",
        "coursePrice": "Course price",
        "freeOfCharge": "Free of charge",
        "legalNotice": "With your confirmation the amount will be invoiced.",
        "message": "Please confirm your booking:",
        "title": "Thank you \u2013 you are about to book this course",
        "waitingListConfirmationMessage": "You have been added to the waiting list.",
        "waitingListConfirmationTitle": "Confirmation"
    },
    "c-course-lecturer": {
        "learnMore": "Learn more"
    },
    "c-course-organizer": {
        "organizerEmail": "Email {email}",
        "organizerPhone": "Phone {number}",
        "organizerTitle": "Questions about the course?"
    },
    "c-course-questionnaire": {
        "confirmationTitle": "Thank you for completing the questionnaire for \"{course}\".",
        "content": "<h4>Let's share your thoughts about it!<\/h4>\n",
        "continueToAcademy": "Back to academy",
        "continueToCourse": "Back to course",
        "mandatoryHint": "Mandatory questions",
        "question1": "How satisfied are you with the lecture content?",
        "question2": "How satisfied are you with the quality of the used media (presentation, images, visuals etc.)?",
        "question3": "How satisfied are you with the speaker\/instructor?",
        "question4": "All in all, how satisfied are you with the course in general?",
        "question5": "What would you change in order to improve future experiences?",
        "ratingHighLabel": "Very satisfied",
        "ratingLowLabel": "Very dissatisfied",
        "submitLabel": "Send",
        "title": "Thank you for attending the course \"{course}\"."
    },
    "c-course-tile": {
        "availableSeats": "1 spot available | {count} spots available",
        "calendarButton": "Calendar",
        "cancelButton": "Hide course",
        "ceBadge": "CE",
        "cePoints": "CE-Points",
        "detailLink": "More details",
        "favouriteButton": "Favorite",
        "isFree": "Free",
        "lecturer": "By {name}",
        "localPoints": "No Points | +1 Point | +{count} Points",
        "localPointsShort": "LP",
        "onDemand": "On-demand",
        "points": "Points",
        "waitingList": "Waiting list"
    },
    "c-dashboard": {
        "title": "My Academy",
        "titleCurrentCourses": "My current courses",
        "titleFavourites": "My latest favourites",
        "viewAll": "View all"
    },
    "c-data-table": {
        "noResults": "No results",
        "sortAscending": "{sortName} ascending",
        "sortBy": "Sort by",
        "sortDescending": "{sortName} descending"
    },
    "c-date-picker": {
        "calendarTitle": "Date Range",
        "close": "Close",
        "inputEndName": "To:",
        "inputName": "Date:",
        "inputStartName": "From:",
        "nextMonth": "Next month",
        "previousMonth": "Previous month"
    },
    "c-document-card": {
        "collapse": "Show less",
        "readMore": "Read more"
    },
    "c-download-list": {
        "archive": "Archive",
        "image": "Image",
        "pdf": "PDF document",
        "video": "Video"
    },
    "c-electronic-instruction-banner": {
        "invalidReferenceNumberError": "Your search term does not match the format of a reference number\/UDI-DI. Please check the format or contact us if you need any help.",
        "legalNotice": "Please note that this information is for professionals only. By using this web page, you confirm that you are a dental professional.",
        "prefix": "Always at hand \u2026",
        "referenceNumberExampleAlt": "An example on how to find the reference number for your product.",
        "referenceNumberInfo": "You can find the product reference number (REF number) printed on the side of the packaging of your product as shown {tooltip}. If you cannot find the REF number, please use the website search and enter the brand name. ",
        "referenceNumberTooltipLabel": "here",
        "searchFieldLabel": "Search by REF number...",
        "searchUrlLabel": "Search",
        "title": "Welcome to the electronic Instructions for Use (eIFU)"
    },
    "c-electronic-instruction-detail": {
        "currentVersion": "Current version",
        "historyTitle": "Earlier versions",
        "readInstructions": "Read the instructions on how to use eIFU",
        "titleValidAsOf": "Valid as of {date}",
        "validAsOf": "Valid as of {date}"
    },
    "c-electronic-instruction-download": {
        "buttonLabelBack": "Back",
        "buttonLabelClose": "Close",
        "buttonLabelDownload": "Download",
        "buttonLabelSubscribeAndDownload": "Subscribe and download",
        "description": "By subscribing to these eIFU we will update you about all changes regarding this eIFU via the email address you have provided.\u00a0",
        "errorNotificationEmail": "Please enter a valid email address.",
        "formHeader": "Please enter your e-mail address.",
        "inputLabelEmail": "e-mail address",
        "inputLabelGeneralTermsOfUse": "I agree to the {link}",
        "inputLabelGeneralTermsOfUseLink": "General Terms and Conditions.",
        "radioLabelDownload": "No, I don't want to subscribe.",
        "radioLabelSubscribe": "Yes, I want to subscribe to all future versions of this eIFU.",
        "textConfirmationMessage": "We have sent you a confirmation email. Please click the link within the email to activate your subscription.",
        "title": "Subscribe to all new versions",
        "titleConfirmation": "You have subscribed to updates"
    },
    "c-electronic-instruction-grid-tile": {
        "category": "Category",
        "language": "Language",
        "linkTitle": "More details",
        "referenceNumber": "REF\/Article number",
        "statusTextImprovedVersionExists": "This eIFU version was changed. Please use the following eIFU version.",
        "statusTextInvalidDueSafety": "This eIFU version was changed due to safety reasons and was invalidated. Please use the following eIFU version.",
        "udiDiNumber": "UDI-DI",
        "validAsOf": "Valid as of {date}"
    },
    "c-electronic-instruction-list": {
        "multiLanguageVersion": "Multilanguage"
    },
    "c-electronic-instruction-problem": {
        "buttonLabelBack": "Back",
        "buttonLabelClose": "Close",
        "buttonLabelSubmit": "Submit",
        "errorNotificationEmail": "Sorry, but this is not a valid e-mail",
        "errorNotificationFieldRequired": "This field is mandatory",
        "formTitle": "Report a problem about the eIFU",
        "inputLabelComment": "Additional Comment",
        "inputLabelCompanyName": "Company name",
        "inputLabelEmail": "Email",
        "inputLabelFirstName": "First name",
        "inputLabelGeneralTermsOfUse": "Yes, I have read and understood {link}",
        "inputLabelGeneralTermsOfUseLink": "the General Terms of Use",
        "inputLabelLastName": "Last name",
        "inputLabelPhone": "Telephone",
        "inputLabelSalutation": "Salutation",
        "messageApology": "We apologize for not meeting your expectations.",
        "messageInstructions": "Please provide us with a short description and your contact details. We will contact you as quickly as possible.",
        "salutationOptionMr": "Mr",
        "salutationOptionMs": "Ms",
        "textConfirmationMessage": "Thank you for submitting your report.",
        "titleConfirmation": "Your report has reached us"
    },
    "c-electronic-instruction-request": {
        "buttonLabelBack": "Back",
        "buttonLabelClose": "Close",
        "buttonLabelSubmitForm": "Submit",
        "errorNotificationEmail": "Sorry, but this is not a valid e-mail",
        "errorNotificationFieldRequired": "This field is mandatory",
        "formTitle": "Request a hard copy of the eIFU",
        "genderOptionFemale": "Ms",
        "genderOptionMale": "Mr",
        "genderOptionNotDisclosed": "Rather not to disclose",
        "inputLabelAddress": "Address",
        "inputLabelCity": "City",
        "inputLabelComment": "Additional comment",
        "inputLabelCompanyName": "Company name",
        "inputLabelCountry": "Country",
        "inputLabelEmail": "Email",
        "inputLabelFirstName": "First name",
        "inputLabelGender": "Salutation",
        "inputLabelGeneralTermsOfUse": "I accept the {link}",
        "inputLabelGeneralTermsOfUseLink": "General Terms of Use",
        "inputLabelLastName": "Last name",
        "inputLabelPhone": "Telephone",
        "inputLabelTitle": "Title",
        "inputLabelZipCode": "Post code",
        "propertyToggleLabelCollapse": "Collapse",
        "propertyToggleLabelExpand": "Expand",
        "referenceNumber": "Reference number",
        "textConfirmationMessage": "Thank you for submitting your request for a paper version of the IfU. We will send it to you within one week by mail.",
        "titleConfirmation": "Your request has reached us",
        "udiDiNumber": "UDI-DI"
    },
    "c-electronic-instruction-search": {
        "brandSearchFieldLabel": "Search by product name...",
        "invalidReferenceNumberError": "Your search term does not match the format of a reference number\/UDI-DI. Please check the format or contact us if you need any help.",
        "refSearchFieldLabel": "Search by REF number...",
        "referenceNumberExampleAlt": "An example on how to find the reference number for your product.",
        "referenceNumberInfo": "By searching for the reference number (REF number), you get the exact result for your product. You can find the product REF number printed on the side of the packaging of your product as shown {tooltip}. If you cannot find the REF number, please use the search on the right side and enter the product name.",
        "referenceNumberTooltipLabel": "here",
        "searchByBrandHint": "By searching for the product name, you will find many results that match the name. Please make sure you pick the correct eIFU. Please enter the name of your desired product. If you are unsure which eIFU is right for your product, please do not hesitate to contact us.",
        "searchByBrandTitle": "Search by name",
        "searchByRefTitle": "Search by REF number",
        "searchUrlLabel": "Search",
        "separatorLabel": "or"
    },
    "c-electronic-instruction-tile": {
        "availableLanguages": "Available languages",
        "category": "Category",
        "countriesApplicable": "Applicable in the following countries",
        "download": "Download",
        "earlierVersions": "Earlier versions",
        "fileId": "File ID",
        "fileSize": "File size",
        "fileType": "File type",
        "fileTypePDF": "PDF",
        "languages": "Languages",
        "moreToggleLabel": "more",
        "noMatch": "No match",
        "propertyToggleLabelCollapse": "Collapse",
        "propertyToggleLabelExpand": "Expand",
        "referenceNumber": "REF\/Article number",
        "reportProblem": "Report a problem about the eIFU",
        "requestHardCopy": "Request hard copy",
        "showLess": "Show less",
        "statusTextImprovedVersionExists": "This eIFU version was changed. Please use the following eIFU version.",
        "statusTextInvalidDueSafety": "This IFU version was changed due to safety reasons and was invalidated. Please use the following eIFU version.",
        "udiDiNumber": "UDI-DI",
        "validAsOf": "Valid as of {date}",
        "view": "View"
    },
    "c-favourite-courses": {
        "listTitle": "You have no saved courses. | Your saved courses (1) | Your saved courses ({count})"
    },
    "c-filter": {
        "selectPlaceholder": "Please select",
        "unsupportedTypeError": "Filter type '{type}' is not yet supported."
    },
    "c-flyout": {
        "closeButtonTitle": "Close"
    },
    "c-footer": {
        "certificatesLabel": "This site is secure",
        "socialLabel": "Follow us on our social media",
        "toTopLabel": "Go to top"
    },
    "c-gatekeeper-modal": {
        "cancelLabel": "Cancel",
        "confirmLabel": "Yes",
        "declineLabel": "No",
        "message": "Welcome to our website. This site is for dental professional (dentist, dental technician, dental, \u2026). If you are dental professional, please click \"Yes\". Thank you."
    },
    "c-header": {
        "cartAlt": "Cart",
        "cartTitle": "Cart",
        "logoAlt": "Logo",
        "menuAlt": "Navigation",
        "searchAlt": "Search",
        "searchLabel": "Search now for \u2026",
        "userGreeting": "Welcome, {name}."
    },
    "c-hero-message": {
        "pimcorePictureOverlayVariantLabel": "Gradient mask (image)",
        "pimcorePictureOverlayVariantLabelDark": "Dark",
        "pimcorePictureOverlayVariantLabelLight": "Light",
        "pimcorePictureOverlayVariantLabelRegular": "Regular"
    },
    "c-ids-menu-tile": {
        "showMore": "Learn more",
        "tabTitleGeneral": null,
        "tabTitleLink": null
    },
    "c-ids-product-card": {
        "detailLink": "Learn more"
    },
    "c-ids-screensaver": {
        "tabToStartLink": "Zum Starten den Bildschirm ber\u00fchren \/ Please touch screen to start"
    },
    "c-ids-workflow-detail": {
        "stepLabel": "{index}. {text}"
    },
    "c-ids-workflow-step": {
        "moreOnIvoclar": "More on Ivoclar"
    },
    "c-ids-workflow-steps": {
        "stepLabel": "{index}. {text}"
    },
    "c-ids-workflows-overview": {
        "showMore": "Learn more"
    },
    "c-language-menu": {
        "changeRegion": "Change region",
        "title": "Choose language",
        "toggleFallback": "Language"
    },
    "c-main-navigation-mobile": {
        "backButtonTitle": "Back to {label}",
        "backToOverview": "Back to overview"
    },
    "c-main-navigation": {
        "closeButtonTitle": "Close"
    },
    "c-market-selector": {
        "languageLabel": "Language",
        "marketLabel": "Country",
        "submitLabel": "Go",
        "text": "Come visit our site in your country! Choose your region from the list below:",
        "title": "Choose your country"
    },
    "c-modal": {
        "closeTitle": "Close modal"
    },
    "c-newsletter": {
        "emailLabel": "Your e-mail address",
        "tocLabel": "I've read the {link}.",
        "tocLinkLabel": "TOC"
    },
    "c-notification": {
        "close": "Close",
        "confirm": "OK",
        "decline": "Cancel",
        "errorTitle": "Error",
        "infoTitle": "Info",
        "successTitle": "Confirmation",
        "warningTitle": "Warning"
    },
    "c-pagination": {
        "backButtonTitle": "Previous page",
        "forwardButtonTitle": "Next page",
        "itemsPerPageLabel": "Items per page",
        "selectPageLabel": "Select page"
    },
    "c-personalized-message": {
        "message": "{salutation} {greeting}!<br \/> In your personal Ivoclar customer area you will find all relevant information, solutions and services.",
        "salutationFemale": "Dear Mrs.",
        "salutationMale": "Dear Mr.",
        "salutationOther": "Welcome"
    },
    "c-product-tile": {
        "detailLink": "More details",
        "shopLink": "Go to the online shop"
    },
    "c-profile-navigation-trigger": {
        "label": "My account"
    },
    "c-profile-navigation": {
        "closeButton": "Close",
        "titleAcademy": "Academy",
        "titlePortalFeatures": "Portal features",
        "titleProfile": "My profile",
        "titleShop": "Shop"
    },
    "c-quiz": {
        "buttonRetry": "Retry",
        "courseFailedLink": "Watch lesson again",
        "coursePassedLink1": "Back to course",
        "coursePassedLink2": "Next course",
        "failedText": "You have answered {number}% of the questions correctly. Unfortanetly that is not quite enough to get the points. Give it another try!",
        "failedTitle": "So close!",
        "passedText": "You have answered enough questions correctly to pass the course. Very good! You will receive your certificate by email. Start the next course now.",
        "passedTitle": "Congratulations!",
        "submitButton": "Check and get points",
        "title": "Quiz"
    },
    "c-revealable-text": {
        "buttonLabel": "Read more"
    },
    "c-scroll-top": {
        "buttonTitle": "top"
    },
    "c-search-banner": {
        "closeButtonTitle": "Close",
        "hasResultsText": "Not what you are looking for? Try to search in the {link}, please.",
        "hasResultsTextLink": "shop",
        "noResultsLinkTextShopTab": "contact us",
        "noResultsLinkTextWebsiteTab": "contact us",
        "noResultsText": "No results, try to search in the shop",
        "noResultsTextLink": "shop",
        "noResultsTextShopDisabled": "Sorry, we could not find any results.",
        "noResultsTextShopTab": "Sorry, we could not find any result matching your search term. If you are missing any information, please {link}.",
        "noResultsTextWebsiteTab": "Sorry, we could not find any result matching your search term. If you are missing any information, please {link}.",
        "relatedResultsTitle": "Most searched",
        "searchFieldLabel": "I search for \u2026",
        "searchResultsTitle": "Search results",
        "submitSearchButtonText": "Search",
        "tabShop": "Shop",
        "tabWebsite": "Website",
        "titleRow1": "Hello {name}, ",
        "titleRow2": "How can we help you?"
    },
    "c-search-bar": {
        "closeLabel": "Close",
        "hasResultsText": "Not what you are looking for? Try to search in the {link}, please.",
        "hasResultsTextLink": "shop",
        "noResultsLinkText": "To the contact form",
        "noResultsLinkTextShopTab": "contact us",
        "noResultsLinkTextWebsiteTab": "contact us",
        "noResultsText": "No results, try to search in the shop",
        "noResultsTextLink": "shop",
        "noResultsTextShopDisabled": "Sorry, we could not find any results.",
        "noResultsTextShopTab": "Sorry, we could not find any result matching your search term. If you are missing any information, please {link}.",
        "noResultsTextWebsiteTab": "Sorry, we could not find any result matching your search term. If you are missing any information, please {link}.",
        "quickLinksTitle": "Quick links",
        "searchLabel": "Search for \u2026",
        "searchSuggestionsTitle": "Results",
        "showAllText": "Show all",
        "tabShop": "Shop",
        "tabWebsite": "Website"
    },
    "c-select": {
        "optionsEmpty": "No results.",
        "save": "Save",
        "search": "search",
        "searchTitle": "Search"
    },
    "c-slider-1": {
        "nextLabel": "Next",
        "previousLabel": "Previous"
    },
    "c-slider-2": {
        "nextLabel": "Next",
        "previousLabel": "Previous"
    },
    "c-social-sharing": {
        "linkTitle": "Share on {platform}"
    },
    "c-status-message": {
        "error_code_0": "Welcome! Your email has been confirmed.<br \/> In your personal Ivoclar customer area you will find all relevant information, solutions and services.",
        "error_code_403002": "Sorry, the link has expired.",
        "error_code_other": "Unfortunately, there was a problem."
    },
    "c-teaser-1": {
        "showAdditionalInfoBoxLabel": "Show additional info box (with blue background)",
        "showAdditionalInfoBoxText": "This product is not available for purchase by the general public. Always follow the directions for use."
    },
    "c-user-courses": {
        "cancelBookingConfirmationLabel": "Cancel",
        "cancelBookingText": "If you decide to continue, this course will be hidden from your list. This can not be undone.",
        "cancelBookingTitle": "Hide course",
        "confirmBookingConfirmationLabel": "Continue",
        "filterButtonText": "Filter ({amount})",
        "filterTitle": "Filter",
        "listTitle": "Your upcoming courses ({count})",
        "listTitleCompletedCourses": "Your completed courses ({count})",
        "listTitleUncompletedCourses": "Your upcoming courses ({count})",
        "resetAllFilterText": "Reset all filters ({amount})",
        "submitFilterText": "Apply filters"
    },
    "c-user-navigation": {
        "loginButtonText": "Login",
        "logoutButtonText": "Logout"
    },
    "c-welcome-modal": {
        "actionCloseLabel": "Thanks, close this info",
        "title": "Hello {name}\nWe are happy you are here!"
    },
    "e-course-availability": {
        "availableSeats": "1 spot available | {count} spots available",
        "waitingList": "Waiting list"
    },
    "e-date": {
        "defaultLabel": "Date:"
    },
    "e-progress": {
        "loading": "Loading \u2026"
    },
    "e-search": {
        "reset": "Reset",
        "submit": "Search"
    },
    "e-select": {
        "chooseOption": "Please choose"
    },
    "e-table": {
        "noResults": "No results for the current settings.",
        "sort": "Sort by {name}"
    },
    "form": {
        "label,my": {
            "labelFirst Name": null
        },
        "labelFirst Name": null
    },
    "form_builder": {
        "dynamic_multi_file": {
            "active_drop_area": null,
            "additions_removals": "additions removals",
            "cancel": "cancel",
            "canceled": "canceled",
            "close": "close",
            "delete": "delete",
            "delete_failed": "Delete failed",
            "deleting": "Deleting...",
            "drop_files_here": "Drop files here",
            "edit_filename": "edit filename",
            "file_invalid_extension": "The file has an invalid extension. Valid extension(s): {extensions}.",
            "file_is_empty": "The file is empty, please select files again without it.",
            "file_is_too_large": "The file is too large, maximum file size is {sizeLimit}MB.",
            "file_is_too_small": "The file is too small, minimum file size is {minSizeLimit}",
            "files_uploaded": "The files are being uploaded, if you leave now the upload will be canceled.",
            "global": {
                "cannot_destroy_active_instance": "This uploader is currently active or has some unprocessed files. in case there are some uploaded files, please remove them first."
            },
            "image_not_tall_enough": "Image is not tall enough.",
            "image_not_wide_enough": "Image is not wide enough.",
            "image_too_tall": "Image is too tall.",
            "image_too_wide": "Image is too wide.",
            "no": "no",
            "no_files_to_upload": "No files to upload.",
            "ok": null,
            "paused": "Paused",
            "percent_of_size": "{percent}% of {total_size}",
            "processing": "Processing...",
            "processing_dropped_files": "Processing dropped files...",
            "remove": "remove",
            "retry": "retry",
            "retry_failed_limit": "Retry failed - you have reached your file limit.",
            "sure_to_cancel": "Are you sure you want to cancel?",
            "sure_to_delete": "Are you sure you want to delete {filename}?",
            "too_many_items": "Too many items would be uploaded.",
            "unrecoverable_error": "Unrecoverable error - this browser does not permit file uploading of any kind due to serious bugs in iOS8 Safari. Please use iOS8 Chrome until Apple fixes these issues.",
            "upload_a_file": "upload a file",
            "upload_failed": "Upload failed",
            "yes": "yes"
        },
        "fatal_captcha_error": "An unknown error occurred while loading form relevant assets. Please contact the administrator.",
        "form": {
            "container": {
                "repeater": {
                    "max": "%label%: Only %items% item(s) allowed.",
                    "min": "%label%: You need to add at least %items% items."
                }
            }
        },
        "reCaptchaDisclaimer": "This site is protected by reCAPTCHA and the Google Privacy Policy and Terms of Service apply."
    },
    "form_builder_form_template": {
        "form_ivoclar_layout": "Ivoclar"
    },
    "form_builder_form_template_negative": {
        "form_ivoclar_layout": "Ivoclar negative"
    },
    "globalMessages": {
        "certificateDownloadError": "Download of certificates not possible",
        "loginUnavailable": "An error occurred during initialising the login and registering functionality. Please inform the administrator.",
        "unknownApiError": "An unknown error occurred.",
        "userAccountNotPrepared": "The used account is not prepared yet.",
        "userAccountNotPreparedTitle": "Account not prepared",
        "userAssignedToDifferentSite": "The used account is assigned to a different site.",
        "userAssignedToDifferentSiteTitle": "Wrong site",
        "userLocked": "The used account is locked.",
        "userLockedTitle": "Account locked"
    },
    "ics": {
        "alert": {
            "30-minutes": null
        }
    },
    "l-badge-certificate": {
        "company": "Ivoclar Academy",
        "statement": "The Ivoclar Academy gives full access<br \/> to the highest level of educational resources from industry<br \/> leaders across the globe.",
        "subtitle": "Confirms the rank for",
        "title": "Certificate"
    },
    "l-blog-list": {
        "filterButtonText": "Filter",
        "filterTitle": "Filter",
        "itemsPerPageLabel": "Items per page",
        "noResultsText": "No results",
        "resetAllFilterText": "Reset all filters ({amount})",
        "sortingLabel": "Sort by",
        "sortingLabelDateAsc": "Date ascending",
        "sortingLabelDateDesc": "Date descending",
        "sortingViewsAsc": "Views ascending",
        "sortingViewsDesc": "Views descending",
        "submitFilterText": "Apply filters",
        "topic": "Topic"
    },
    "l-course-certificate": {
        "ceHours": "CE Hours",
        "courseCode": "Course Code",
        "courseDate": "Course Date",
        "courseRegistrationId": "Course registration ID",
        "educationalMethod": "Educational Method",
        "issueId": "Issue ID",
        "localPoints": "Local points",
        "location": "Location",
        "personalLicenseNumber": "License Number",
        "providerAddress": "Provider Address",
        "providerAgdId": "Provider AGD ID#",
        "providerName": "Provider Name",
        "speaker": "Speaker",
        "title": "Certificate",
        "titleSuffix": "of attendance"
    },
    "l-course-detail": {
        "ceLabel": "CE",
        "cePoints": "No CE-Points | +{count} CE-Point | +{count} CE-Points",
        "contactTitle": "Contact",
        "courseNumber": "Course-Nr. {number}",
        "downloadsTitle": "Documents",
        "isFree": "Free",
        "localPoints": "No Points | +1 Point | +{count} Points",
        "localPointsShort": "LP",
        "localTime": "Local time",
        "locationTitle": "Location",
        "mapLinkText": "See on map",
        "notificationMessageBookingApproved": "Course available as soon as it starts",
        "notificationMessageBookingDeadlineOver": "The booking deadline is over",
        "notificationMessageBookingPassed": "Course passed",
        "notificationMessageBookingRegistrationPending": "Registration in progress",
        "notificationMessageBookingRejected": "Registration was rejected",
        "notificationMessageBookingWaitingList": "Registered for waiting list",
        "notificationMessageUserVerificationPending": "User verification in progress",
        "organizerEmail": "Email {email}",
        "organizerPhone": "Phone {number}",
        "organizerTitle": "Questions about the course?",
        "playVideoLabel": "Play video",
        "points": "No Points | +1 Point | +{count} Points",
        "recommendationsTitle": "Recommended courses",
        "utc": "UTC"
    },
    "l-course-list": {
        "filterButtonText": "Filter ({amount})",
        "filterTitle": "Filter",
        "itemsPerPageLabel": "Items per page",
        "moreFilters": "Advanced filter",
        "noResultsText": "No results",
        "resetAllFilterText": "Reset all filters ({amount})",
        "sortingLabel": "Sorting",
        "sortingLabelDateAsc": "Date ascending",
        "sortingLabelDateDesc": "Date descending",
        "submitFilterText": "Apply filters",
        "title": "Learning opportunities ({amount})"
    },
    "l-course-local-certificate": {
        "courseCode": null,
        "courseDate": "course date",
        "educationalMethod": "Educational Method",
        "localPoints": "Local Poins",
        "personalLicenseNumber": "License Number",
        "providerAddress": "Provider Address",
        "providerAgdId": "Provider ID#",
        "providerName": "Provider Name",
        "speaker": "Speaker",
        "title": "Certificate"
    },
    "l-electronic-instruction-list": {
        "languageVersion": "{language} version | Multilanguage version",
        "legalNotice": "Please note that this information is for professionals only. By using this web page, you confirm that you are a dental professional.",
        "noBrandResults": "Unfortunately, we could not find a document that matches your search. Please contact us and we will provide you with the requested information as soon as possible.",
        "noBrandResultsNotification": "Unfortunately, we could not find a document that matches your search. Please contact us and we will provide you with the requested information as soon as possible.",
        "noResults": "Sorry, we could not find an asset matching this reference number. Please contact us and we will make the desired information available as fast as possible.",
        "noResultsNotification": "Sorry, we could not find an asset matching this reference number. Please contact us and we will make the desired information available as fast as possible.",
        "onlyHistoricalResults": "This reference number could only be found in historical versions.",
        "reportProblemLabel": "Report an eIFU problem",
        "searchUrlLabel": "Search",
        "teaserText": "To find the applicable instruction for use (IFU) for Ivoclar products, please enter either the product reference number (REF) or alternatively the product name.",
        "title": "Welcome to the electronic Instructions for Use (eIFU)"
    },
    "l-ids-business-card-scanner": {
        "cameraPermissionRevoked": "Refuse camera permission",
        "cameraTitle": "Business card scanner",
        "description": "Take a picture of the business card using the button below",
        "formTitle": "Business card scanner",
        "takePhoto": "Take photo",
        "takePhotoAgain": "Take photo again",
        "takenPhotoDescription": "If you need take picture once again"
    },
    "l-ids-homepage": {
        "headlineMenuPreview": null,
        "menuDescription": null
    },
    "l-product-list": {
        "filterButtonText": "Filter {amount}",
        "filterTitle": "Filter",
        "itemsPerPageLabel": "Items per page",
        "noResultsText": "No results",
        "resetAllFilterText": "Reset all filters {amount}",
        "submitFilterText": "Apply filters",
        "title": "Products {amount}"
    },
    "l-search-results": {
        "filterButtonText": "Filter",
        "filterTitle": "Filter",
        "indexAll": "All results ({count})",
        "indexArticle": "Articles ({count})",
        "indexBlog": "Blog ({count})",
        "indexCourse": "Academy ({count})",
        "indexDocuments": "Documents ({count})",
        "indexEifu": "eIFU ({count})",
        "indexLabel": "Results",
        "indexLabelAll": "All results",
        "indexLabelArticles": "Articles",
        "indexLabelBlog": "Blog ",
        "indexLabelCourse": "Academy",
        "indexLabelDocuments": "Documents",
        "indexLabelEifuasset": "eIFU",
        "indexLabelEifuassets": "eIFU",
        "indexLabelProduct_objects": null,
        "indexLabelProducts": "Products",
        "indexLabelPublications": "Publications",
        "indexLabelSolutions": "Solutions",
        "indexLabelUndefined": "Undefined",
        "indexProduct": "Products ({count})",
        "indexPublications": "Publications ({count})",
        "indexShop": "Shop",
        "indexSolution": "Solutions ({count})",
        "indexUndefined": "Undefined ({count})",
        "itemPerPageSelect": "Results",
        "itemsPerPageLabel": "Items per page",
        "resetAllFilterText": "Reset all filters ({amount})",
        "searchClearLabel": "Clear",
        "searchTerm": "Search term",
        "submitFilterText": "Apply filters",
        "title": "No results found for \"{term}\" | We found 1 match for \"{term}\", for more products click on shop tap | We found {count} results for \"{term}\", for more products click on shop tap ",
        "titleLoadingResults": "Loading results",
        "titleNoQuery": "No search term given"
    },
    "l-services": {
        "accountDeviceRegistrationCancelLabel": "Cancel",
        "accountDeviceRegistrationConfirmLabel": "Register for free",
        "accountDeviceRegistrationText": "With your current account profile you cannot benefit from the full range of services. Please upgrade your account.",
        "accountDeviceRegistrationTitle": "Login to your account to register your device",
        "accountUpdateAndDeviceRegistrationCancelLabel": "Cancel",
        "accountUpdateAndDeviceRegistrationConfirmLabel": "Upgrade for free",
        "accountUpdateAndDeviceRegistrationText": "With your current account profile you cannot benefit from the full range of services. Please upgrade your account.",
        "accountUpdateAndDeviceRegistrationTitle": "Upgrade your account to register your device",
        "accountUpdateConfirmLabel": "Upgrade for free",
        "accountUpdateText": "With your current account profile you cannot benefit from the full range of services. Please upgrade you account.",
        "accountUpdateTitle": "Upgrade your account",
        "cancelaccountUpdateLabel": "Cancel",
        "loginLabel": "Login",
        "signupPendingLabel": "Quick update",
        "signupPendingMessage": "We kindly ask you to be patient until we notify you by email that the full range of services is available to you.",
        "signupSuccessLabel": "Quick update",
        "signupSuccessMessage": "All your Customer Portal functions are activated. Place your first order or book your course now.",
        "upgradeButtonLabel": "Upgrade for free",
        "upgradeNotificationLabel": "Quick update",
        "upgradeNotificationMessageAllServices": "All your Customer Portal functions are activated. Place your first order or book your course now.",
        "upgradeNotificationMessageBasic": "Upgrade for free to get full access to all functionalities",
        "upgradeNotificationMessageSignup": "Sign up now to take advantage!",
        "upgradeNotificationMessageUpgradePending": "We kindly ask you to be patient until we notify you by email that the full range of services is available to you."
    },
    "simpleevent": {
        "ics": {
            "alert": {
                "1-day": null,
                "30-minutes": null
            }
        }
    }
};